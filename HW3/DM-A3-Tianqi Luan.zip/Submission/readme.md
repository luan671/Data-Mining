HeartDiseaseDatasetStudy
------------------------------------------------------
For this project I applied logistic regression and RandomForestClassifier model to the Cleveland Heart Disease data set.

1. Original dataset cleveland.mod was opened with notepad and converted to cleveland.txt
2. Conversion from cleveland.txt to .csv file and submission for all text cell to corresponding integer was done on Excel
3. All work on Cleveland.csv was done on JupyterNotebook......cleveland-fivecalss.ipynb